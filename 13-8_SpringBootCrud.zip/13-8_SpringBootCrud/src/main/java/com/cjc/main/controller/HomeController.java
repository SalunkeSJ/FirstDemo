package com.cjc.main.controller;

import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cjc.main.model.Student;
import com.cjc.main.service.HomeService;

@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@Autowired
	HomeService hs;

	@RequestMapping("/")
	public String preLogin() {
		return "login";
	}

	@RequestMapping("/registration")
	public String Registerpage() {
		return "registration";
	}

	@RequestMapping("/reg")
	public String savedata(@ModelAttribute Student s) {
		hs.saveData(s);
		logger.info("Data Saved Succesfully");
		return "login";
	}

	@RequestMapping("/login")
	public String logindata(@RequestParam("uname") String un, @RequestParam("password") String pas, Model m) {
		Student s = hs.RegisterLogin(un, pas);

		if (s != null) {
			Iterable<Student> all = hs.getAlldata();
			m.addAttribute("data", all);
			logger.info("Login Succesfully");
			return "success";

		} else {
			return "login";
		}
	}

	@RequestMapping("/delete")
	public String Deletedata(@ModelAttribute("Student") Student s, Model m) {
		hs.deleteData(s);
		logger.info("data deleted Succesfully");
		Iterable<Student> list = hs.getAlldata();
		m.addAttribute("data", list);

		return "success";

	}

	@RequestMapping("/edit")
	public String Editdata(@RequestParam("uid") int uid, Model m) {
		logger.info("uid: " + uid);
		Student s = hs.Editdata(uid);
		m.addAttribute("data", s);

		return "edit";
	}

	@RequestMapping("/update")
	public String Updatedata(@ModelAttribute("student") Student s, Model m) {
		hs.saveData(s);
		Iterable<Student> Alldata = hs.getAlldata();
		m.addAttribute("data", Alldata);
		logger.info("data Updated Succesfully");
		return "success";

	}

}
