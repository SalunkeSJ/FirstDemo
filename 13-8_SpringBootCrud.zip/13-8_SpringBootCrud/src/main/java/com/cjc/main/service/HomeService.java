package com.cjc.main.service;

import com.cjc.main.model.Student;

public interface HomeService {

	public void saveData(Student s);
	public Student RegisterLogin(String un,String pas);
	public Iterable<Student> getAlldata();
	public void deleteData(Student s);
	public Student Editdata(int uid);
}
